from django.db import models
from django.contrib.auth.models import User



# Create your models here.
# class demodata(models.Model):
#     img_name =   img_name = models.CharField(max_length=60,default="")
#     img_id  = models.AutoField
#     img_flag = models.CharField(max_length=60,default="")
#     img_src = models.ImageField(upload_to= "static/l3images",default="")

#     def __str__(self):
#         return self.img_name
    
 

class level1data(models.Model):
    img_name = models.CharField(max_length=60,default="")
    img_id = models.CharField(max_length=60,default="")
    img_data = models.CharField(max_length=60,default="")
    img_flag = models.CharField(max_length=60,default="")
    img_src = models.ImageField(upload_to= "static/l3images",default="")

    def __str__(self):
        return self.img_name
    


class level2data(models.Model):
    img_name = models.CharField(max_length=60,default="")
    img_id=models.AutoField(primary_key=True)
    img_data = models.CharField(max_length=60,default="")
    img_flag = models.CharField(max_length=60,default="")
    img_src = models.ImageField(upload_to= "static/l3images",default="")

    def __str__(self):
        return self.img_name
    


class level3data(models.Model):
    img_name = models.CharField(max_length=60,default="")
    img_id = models.CharField(max_length=60,default="")
    img_data = models.CharField(max_length=60,default="")
    img_flag = models.CharField(max_length=60,default="")
    img_src = models.ImageField(upload_to= "static/l3images",default="")

    def __str__(self):
        return self.img_name
    


class clickCount(models.Model):
    levels  = models.CharField(max_length=60,default="")
    count = models.IntegerField(default=3)
    AdditionalCount =  models.IntegerField(default=0)

    def __str__(self):
        return self.levels



class answers(models.Model):
     levels  = models.CharField(max_length=60,default="")
     answer = models.CharField(max_length=60,default="")

     def __str__(self):
        return self.levels


class Scores(models.Model):
    levels  = models.CharField(max_length=60,default="")
    score = models.IntegerField(default=0)
    flag = models.BooleanField(default=False)
    def __str__(self):
        return self.levels

    
class FinalScore(models.Model):
    name =  models.CharField(max_length=60,default="")
    Fscore = models.IntegerField(default=0)
    def __str__(self):
        return self.name
