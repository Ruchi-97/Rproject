
from django.contrib import admin
from django.urls import path ,include 
from django.conf.urls import handler400
from django.conf.urls import url
from myapp import views
from django.contrib import messages

urlpatterns = [
  path("",views.index, name='index'),
 
  path('register',views.register,name='register'),
  path("index.html",views.ind,name="ind"),
  path('login',views.loginuser,name='login'),
  path('logout',views.logoutuser,name='logout'), 
  path("level1.html",views.level1, name='level1'),
  path("demo.html",views.demo, name='demo'),
  path("level2.html",views.level2, name='level2'),
  path("level3.html",views.level3, name='level3'),
  path('click',views.click,name='click'),
  

]
