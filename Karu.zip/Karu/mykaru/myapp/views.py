from django.shortcuts import render ,HttpResponse,redirect
from django.contrib.auth import login,authenticate,logout
from django.contrib import messages #import messages
from django.contrib.auth.models import User
from myapp.models import level1data,level2data , level3data ,clickCount,answers,Scores,FinalScore
from json import dumps , JSONDecodeError,JSONDecoder,JSONEncoder
import json


# Create your views here.

def demo(request):
	return render(request ,'demo.html')


def  index(request):
    return render(request ,'index.html')

def ind(request):
	return render(request ,'index.html')

def level1(request,default='default'):
	def refresh_from_db(self, using=None, fields=None, **kwargs):
		if fields is not None:
				fields = set(fields)
				deferred_fields = self.get_deferred_fields()
				# If any deferred field is going to be loaded
				if fields.intersection(deferred_fields):
					# then load all of them
					fields = fields.union(deferred_fields)
		super().refresh_from_db(using, fields, **kwargs)

	print(default)
	imag = level1data.objects.all()
	num=len(imag)
	c  = clickCount.objects.get(levels="level1")
	cnt = int(c.count)
	c.save()
	c.refresh_from_db()
	a = answers.objects.get(levels="level1")
	ans = a.answer
	params = { 'level1imag':imag ,
	'range':range(num),'cnt':c.count, 'ans':ans,

	}
	# level1.refresh_from_db()

	return render(request,"level1.html",params)

def level2(request):
	imag = level2data.objects.all()
	num=len(imag)
	params = { 'level2imag':imag,'range':range(num)

	}
	return render(request,"level2.html",params)


def level3(request):
	imag = level3data.objects.all()
	num=len(imag)
	params = { 'level3imag':imag,'range':range(num)

	}
	return render(request,"level3.html",params)


# login
def loginuser(request):
	if request.method =="POST":
		lusername = request.POST['loginusername']
		lpass = request.POST['loginpass']
		user = authenticate(username = lusername,password = lpass)
		if user is not None:
			login(request,user)
			messages.success(request,"Successfully logged in")
			# AllLogin.objects.create(lusername)
			return redirect('index.html')

		else:
			messages.error(request,'Inavlid Credentials ,Please try again')
			return redirect('index.html')
	else:
		return HttpResponse('404-Not Found')

#logout 
def logoutuser(request):
	imag = level1data.objects.all()
	for i in imag:
		i.img_flag = "false"
		i.save()
	c  = clickCount.objects.get(levels="level1")
	c.count= 3
	c.save()
	logout(request)
	messages.success(request,"Logout Successfully")
	return redirect('index.html')

# Register
def register(request):
	if request.method =="POST":
	    #  post parameters
		username = request.POST['username']
		firstname = request.POST['firstname']
		lastname = request.POST['lastname']
		email = request.POST['email']
		pass1 = request.POST['pass1']
		pass2 = request.POST['pass2']

		# check for errorneous inputs
		#username must be of 10 characters
		if len(username)>10:
			messages.error(request,"User name must be less than 10 characters")
			return redirect('index.html') 

		#username should be alphanumeric  
		if not username.isalnum():
			messages.error(request,"User name must be alphanumeric")
			return redirect('index.html') 

		# passwords should match
		if pass1 != pass2:
			messages.error(request,"passwords donot match")
			return redirect('index.html') 


		# create user
		myuser = User.objects.create_user(username, email, pass1)
		myuser.first_name=firstname
		myuser.last_name=lastname
		myuser.save()
		fs  = FinalScore(name=username)
		fs.save()

		messages.success(request," your account has been successfully created")
		return redirect('index.html')
	else:
		return HttpResponse('404-Not Found')

# ClickFunctionalityOfLevel1
def click(request):
		imag = level1data.objects.all()
		num = len(imag)
		print(request.body)
		body_unicode = request.body.decode('utf-8')
		body = json.loads(body_unicode)
		imgId = body['id']
		score = body['score']
		print("score:",score)
		
		
		c  = clickCount.objects.get(levels="level1")
		cnt = c.count
		
		#c.refresh_from_db()


		k = level1data.objects.get(img_id=imgId)
		if k.img_flag=="false":
			k.img_flag="True"
			cnt = cnt-1
			c.count = cnt
			clickCount.objects.update(count=c.count)

		
		
		print(k.img_flag)
		k.save()
		c.refresh_from_db()
		c.save()
		print(c.count)
		k.refresh_from_db()
		

		a = answers.objects.get(levels="level1")
		ans = a.answer
		
		s = Scores.objects.get(levels="level1")
		if(s.flag==False):
			s.score = score
			s.flag=True
			s.save()
			u = FinalScore.objects.get(name=User.username)
			u.Fscore+=score
			u.save()
			u.refresh_from_db()

		if(c.count<=0):
				c.count=0
				c.save()
				return render(request, "level2.html")

	
		params = { 'level1imag':imag ,
			'range':range(num),'cnt':c.count, 'ans':ans,

			}
			

		return render(request, "level1.html",params)

	

 

	

